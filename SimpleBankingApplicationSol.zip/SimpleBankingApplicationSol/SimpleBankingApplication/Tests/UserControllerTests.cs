﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SimpleBankingApplication.Controllers;
using SimpleBankingApplication.Models;
using SimpleBankingApplication.Data;
using Xunit;
using Assert = Xunit.Assert;
using System.Security.Principal;


namespace SimpleBankingApplication.Tests
{

    public class UserControllerTests
    {
        private readonly DbContextOptions<BankingContext> _options;
        private BankingContext _context;

        public UserControllerTests()
        {
            // Setup an in-memory database for testing
            _options = new DbContextOptionsBuilder<BankingContext>()
                .UseInMemoryDatabase(databaseName: "BankingContext")
                .Options;

            _context = new BankingContext(_options);
        }

        public void Dispose()
        {
            // Clean up the in-memory database after each test
            _context.Dispose();
        }

        private void ResetDatabase()
        {
            _context.Database.EnsureDeleted();
            _context = new BankingContext(_options);
        }

        [Fact]
        public void UserCreateMultipleAccounts()
        {
            try
            {
                // Clean up the database
                ResetDatabase();
                // Arrange
                var user = new User { Username = "John Doe" };
                var account1 = new Account { Balance = 0, UserId = 1 };
                var account2 = new Account { Balance = 0, UserId = 1 };
                var account3 = new Account { Balance = 0, UserId = 1 };

                // Act
                _context.Users.Add(user);
                _context.Accounts.Add(account1);
                _context.Accounts.Add(account2);
                _context.Accounts.Add(account3);
                _context.SaveChanges();

                var createdAccounts = _context.Users.Find(1);

                // Assert
                Assert.Equal(3, createdAccounts.Accounts.Count);

                var createdAccount1 = _context.Accounts.Find(account1.AccountId);
                _context.Accounts.Remove(createdAccount1);
                _context.SaveChanges();

                var createdAccount2 = _context.Accounts.Find(account2.AccountId);
                _context.Accounts.Remove(createdAccount2);
                _context.SaveChanges();

                var createdAccount3 = _context.Accounts.Find(account3.AccountId);
                _context.Accounts.Remove(createdAccount3);
                _context.SaveChanges();

                Assert.Equal(0, createdAccounts.Accounts.Count);
            }
            finally
            {
                ResetDatabase();
            }

        }



        [Fact]
        public void UserCanCreateAndDeleteAccount()
        {
            try
            {
                // Clean up the database
                ResetDatabase();
                // Arrange
                var user = new User { Username = "John Doe" };
                var account = new Account { Balance = 0, UserId = 1 };

                // Act
                _context.Users.Add(user);
                _context.Accounts.Add(account);
                _context.SaveChanges();

                var createdAccounts = _context.Users.Find(1);
                Assert.Equal(1, createdAccounts.Accounts.Count);

                var createdAccount = _context.Accounts.Find(account.AccountId);
                _context.Accounts.Remove(createdAccount);
                _context.SaveChanges();

                // Assert
                Assert.Null(_context.Accounts.Find(account.AccountId));
            }
            finally
            {
                ResetDatabase();
            }

        }

        [Fact]
        public void UserCanDepositAndWithdrawFromAccount()
        {
            try
            {
                // Clean up the database
                ResetDatabase();
                // Arrange
                var user = new User { Username = "John Doe" };
                var account = new Account { Balance = 0, UserId = 1 };

                // Act
                _context.Users.Add(user);
                _context.Accounts.Add(account);
                _context.SaveChanges();

                var controller = new UserController(_context);
                controller.Deposit(1, 1, 500);
                _context.SaveChanges();

                controller.Withdraw(1, 1, 200);
                _context.SaveChanges();

                // Assert
                var updatedAccount = _context.Accounts.Find(1);
                Assert.Equal(300, updatedAccount.Balance);
            }
            finally { 
            // Clean up the database
            ResetDatabase();
         }
        }

        [Fact]
        public void AccountCannotHaveLessThan100Balance()
        {
            try
            {
                ResetDatabase();
                // Arrange
                var user = new User { Username = "John Doe" };
                var account = new Account { Balance = 100, UserId = 1 };

                // Act
                _context.Users.Add(user);
                _context.Accounts.Add(account);
                _context.SaveChanges();

                var controller = new UserController(_context);

                // Assert
                Assert.IsAssignableFrom<BadRequestObjectResult>(controller.Withdraw(1, 1, 10));
            }
            finally
            {
                ResetDatabase();
            }
        }
 
        [Fact]
        public void UserCannotWithdrawMoreThan90PercentBalance()
        {
            try
            {
                ResetDatabase();
                // Arrange
                var user = new User { Username = "John Doe" };
                var account = new Account { Balance = 1000, UserId = 1 };

                // Act
                _context.Users.Add(user);
                _context.Accounts.Add(account);
                _context.SaveChanges();
                var controller = new UserController(_context);
                // Assert
                Assert.IsAssignableFrom<BadRequestObjectResult>(controller.Withdraw(1, 1, 910));
            }
            finally
            {
                ResetDatabase();
            }
        }

        [Fact]
        public void UserCannotDepositMoreThan10000InSingleTransaction()
        {
            try
            {
                ResetDatabase();
                // Arrange
                var user = new User { Username = "John Doe" };
                var account = new Account { Balance = 0, UserId = 1 };

                // Act
                _context.Users.Add(user);
                _context.Accounts.Add(account);
                _context.SaveChanges();
                var controller = new UserController(_context);
                // Assert
                Assert.IsAssignableFrom<BadRequestObjectResult>(controller.Deposit(1, 1, 11000));
            }
            finally { ResetDatabase(); }
        }


    }
}
