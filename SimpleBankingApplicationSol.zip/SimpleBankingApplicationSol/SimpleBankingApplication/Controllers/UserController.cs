﻿using BankingApp.Data;
using BankingApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Principal;

namespace BankingApp.Controllers
{
    [ApiController]
    [Route("api/users")]
    public class UserController : ControllerBase
    {
        private readonly BankingContext _context;

        public UserController(BankingContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetUsers()
        {
            var users = _context.Users.Include(u => u.Accounts).ToList();
            return Ok(users);
        }

        [HttpPost]
        public IActionResult CreateUser([FromBody] string username)
        {
            var user = new User { Username = username };
            _context.Users.Add(user);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetUser), new { id = user.UserId }, user);
        }

        [HttpGet("{id}")]
        public IActionResult GetUser(int id)
        {
            var user = _context.Users.Include(u => u.Accounts).FirstOrDefault(u => u.UserId == id);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }


        [HttpPost("{userId}/accounts")]
        public IActionResult CreateAccount(int userId, int minimumBal)
        {
            var user = _context.Users.FirstOrDefault(u => u.UserId == userId);
            if (user == null)
            {
                return NotFound();
            }
            if (minimumBal < 100)
            {
                return BadRequest("Minimum Balance to deposit is $100.");
            }

            var account = new Account { UserId = userId, Balance = minimumBal };
            _context.Accounts.Add(account);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetAccount), new { userId = user.UserId, accountId = account.AccountId }, account);
        }

        [HttpGet("{userId}/accounts")]
        public IActionResult GetAccounts(int userId)
        {
            var accounts = _context.Accounts.Where(a => a.UserId == userId).ToList();
            return Ok(accounts);
        }

        [HttpGet("{userId}/accounts/{accountId}")]
        public IActionResult GetAccount(int userId, int accountId)
        {
            var account = _context.Accounts.FirstOrDefault(a => a.UserId == userId && a.AccountId == accountId);
            if (account == null)
            {
                return NotFound();
            }
            return Ok(account);
        }

        [HttpDelete("{userId}/accounts/{accountId}")]
        public IActionResult DeleteAccount(int userId, int accountId)
        {
            var account = _context.Accounts.FirstOrDefault(a => a.UserId == userId && a.AccountId == accountId);
            if (account == null)
            {
                return NotFound();
            }

            _context.Accounts.Remove(account);
            _context.SaveChanges();
            return NoContent();
        }

        [HttpPost("{userId}/accounts/{accountId}/deposit")]
        public IActionResult Deposit(int userId, int accountId, [FromBody] decimal amount)
        {
            var account = _context.Accounts.FirstOrDefault(a => a.UserId == userId && a.AccountId == accountId);
            if (account == null)
            {
                return NotFound();
            }

            if (amount > 10000)
            {
                return BadRequest("Deposit amount exceeds the maximum limit of $10,000.");
            }

            account.Balance += amount;
            _context.SaveChanges();
            return Ok(account);
        }

        [HttpPost("{userId}/accounts/{accountId}/withdraw")]
        public IActionResult Withdraw(int userId, int accountId, [FromBody] decimal amount)
        {
            var account = _context.Accounts.FirstOrDefault(a => a.UserId == userId && a.AccountId == accountId);
            if (account == null)
            {
                return NotFound();
            }

            if (amount > account.Balance * 0.9m)
            {
                return BadRequest("Withdrawal amount exceeds 90% of the account balance.");
            }

            if (account.Balance - amount < 100)
            {
                return BadRequest("Account balance cannot go below $100.");
            }

            account.Balance -= amount;
            _context.SaveChanges();
            return Ok(account);
        }

    }

}