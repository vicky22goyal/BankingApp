﻿using SimpleBankingApplication.Models;
using Microsoft.EntityFrameworkCore;

using System.Collections.Generic;

namespace SimpleBankingApplication.Data
{
    public class BankingContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Account> Accounts { get; set; }

        public BankingContext(DbContextOptions<BankingContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasMany(u => u.Accounts).WithOne(a => a.User).HasForeignKey(a => a.UserId);
        }

    }
}